import { useEffect, useMemo, useState } from "react";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Copy, Eye, EyeOff, Check, Sparkles, Plug2, Code2 } from "lucide-react";

interface Model {
  id: string;
  owned_by: string;
}

function CopyableField({ label, value, secret = false }: { label: string; value: string; secret?: boolean }) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [shown, setShown] = useState(!secret);

  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      toast({ title: "Copied", description: `${label} copied to clipboard.` });
      setTimeout(() => setCopied(false), 1600);
    } catch {
      toast({ title: "Copy failed", description: "Please copy manually.", variant: "destructive" });
    }
  };

  const display = shown ? value : "•".repeat(Math.min(value.length, 32));

  return (
    <div className="space-y-2">
      <Label className="text-xs uppercase tracking-wide text-muted-foreground">{label}</Label>
      <div className="flex gap-2">
        <Input
          readOnly
          value={display}
          className="font-mono text-sm bg-muted/40"
          onFocus={(e) => e.currentTarget.select()}
        />
        {secret && (
          <Button variant="outline" size="icon" onClick={() => setShown((s) => !s)} title={shown ? "Hide" : "Show"}>
            {shown ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </Button>
        )}
        <Button variant="outline" size="icon" onClick={onCopy} title="Copy">
          {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
        </Button>
      </div>
    </div>
  );
}

function App() {
  const baseUrl = useMemo(() => `${window.location.origin}/v1`, []);
  const [apiKey, setApiKey] = useState<string>("x123456");
  const [models, setModels] = useState<Model[]>([]);
  const [status, setStatus] = useState<"idle" | "ok" | "auth" | "error">("idle");
  const [verifying, setVerifying] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("proxy_api_key");
    if (saved) setApiKey(saved);
    fetch(`${baseUrl}/models`).then((r) => {
      if (r.status === 401) setStatus("auth");
    }).catch(() => {});
  }, [baseUrl]);

  const verify = async () => {
    setVerifying(true);
    setStatus("idle");
    try {
      const r = await fetch(`${baseUrl}/models`, { headers: { Authorization: `Bearer ${apiKey}` } });
      if (r.ok) {
        const data = await r.json();
        setModels(data.data ?? []);
        setStatus("ok");
        localStorage.setItem("proxy_api_key", apiKey);
      } else if (r.status === 401) {
        setStatus("auth");
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    } finally {
      setVerifying(false);
    }
  };

  const curlSnippet = `curl ${baseUrl}/chat/completions \\
  -H "Authorization: Bearer ${apiKey}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "gpt-5.2",
    "messages": [{"role": "user", "content": "Hello"}]
  }'`;

  const pySnippet = `from openai import OpenAI

client = OpenAI(
    base_url="${baseUrl}",
    api_key="${apiKey}",
)

resp = client.chat.completions.create(
    model="claude-sonnet-4-6",
    messages=[{"role": "user", "content": "Hello"}],
)
print(resp.choices[0].message.content)`;

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
        <div className="mx-auto max-w-3xl px-6 py-12">
          <div className="mb-10 text-center">
            <div className="inline-flex items-center gap-2 rounded-full border bg-background/80 px-3 py-1 text-xs font-medium text-muted-foreground shadow-sm">
              <Sparkles className="h-3 w-3" /> OpenAI-compatible · streaming · tool calling
            </div>
            <h1 className="mt-4 text-4xl font-bold tracking-tight">AI Gateway</h1>
            <p className="mt-2 text-muted-foreground">
              One endpoint for OpenAI &amp; Anthropic. Drop into any OpenAI-compatible client.
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Plug2 className="h-5 w-5" /> Connection</CardTitle>
              <CardDescription>Use these credentials in any OpenAI-compatible SDK.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <CopyableField label="Base URL" value={baseUrl} />

              <div className="space-y-2">
                <Label className="text-xs uppercase tracking-wide text-muted-foreground">API Key</Label>
                <div className="flex gap-2">
                  <Input
                    type="password"
                    placeholder="Paste your PROXY_API_KEY"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="font-mono text-sm"
                  />
                  <Button onClick={verify} disabled={verifying || !apiKey}>
                    {verifying ? "Verifying…" : "Verify"}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Set as <code className="font-mono">PROXY_API_KEY</code> on the server. Stored locally in your browser only.
                </p>
              </div>

              {status === "ok" && (
                <div className="rounded-md border border-green-500/30 bg-green-500/10 px-3 py-2 text-sm text-green-700 dark:text-green-400">
                  ✓ Connected. {models.length} models available.
                </div>
              )}
              {status === "auth" && (
                <div className="rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-700 dark:text-red-400">
                  Invalid API key. Double-check the value of <code>PROXY_API_KEY</code>.
                </div>
              )}
              {status === "error" && (
                <div className="rounded-md border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-700 dark:text-amber-400">
                  Network error contacting the gateway.
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Code2 className="h-5 w-5" /> Quick start</CardTitle>
              <CardDescription>Drop-in replacement for the OpenAI API.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="mb-2 text-xs uppercase tracking-wide text-muted-foreground">cURL</div>
                <pre className="overflow-x-auto rounded-md bg-slate-950 p-4 text-xs text-slate-100">{curlSnippet}</pre>
              </div>
              <div>
                <div className="mb-2 text-xs uppercase tracking-wide text-muted-foreground">Python (openai SDK)</div>
                <pre className="overflow-x-auto rounded-md bg-slate-950 p-4 text-xs text-slate-100">{pySnippet}</pre>
              </div>
            </CardContent>
          </Card>

          {models.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Available models</CardTitle>
                <CardDescription>Routed automatically by model prefix.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {models.map((m) => (
                    <div key={m.id} className="flex items-center justify-between rounded-md border bg-background px-3 py-2 text-sm">
                      <code className="font-mono">{m.id}</code>
                      <span className="text-xs text-muted-foreground">{m.owned_by}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          <p className="mt-8 text-center text-xs text-muted-foreground">
            Powered by Replit AI Integrations · gpt/o → OpenAI · claude → Anthropic
          </p>
        </div>
        <Toaster />
      </div>
    </TooltipProvider>
  );
}

export default App;
