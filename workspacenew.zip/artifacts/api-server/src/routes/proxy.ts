import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";

const router: IRouter = Router();

const openai = new OpenAI({
  apiKey: process.env["AI_INTEGRATIONS_OPENAI_API_KEY"] ?? "dummy",
  baseURL: process.env["AI_INTEGRATIONS_OPENAI_BASE_URL"],
});

const anthropic = new Anthropic({
  apiKey: process.env["AI_INTEGRATIONS_ANTHROPIC_API_KEY"] ?? "dummy",
  baseURL: process.env["AI_INTEGRATIONS_ANTHROPIC_BASE_URL"],
});

const MODELS = [
  { id: "gpt-5.4", owned_by: "openai" },
  { id: "gpt-5.2", owned_by: "openai" },
  { id: "gpt-5", owned_by: "openai" },
  { id: "gpt-5-mini", owned_by: "openai" },
  { id: "gpt-5-nano", owned_by: "openai" },
  { id: "gpt-4.1", owned_by: "openai" },
  { id: "gpt-4.1-mini", owned_by: "openai" },
  { id: "gpt-4o", owned_by: "openai" },
  { id: "gpt-4o-mini", owned_by: "openai" },
  { id: "o4-mini", owned_by: "openai" },
  { id: "o3", owned_by: "openai" },
  { id: "o3-mini", owned_by: "openai" },
  { id: "claude-opus-4-7", owned_by: "anthropic" },
  { id: "claude-opus-4-6", owned_by: "anthropic" },
  { id: "claude-opus-4-5", owned_by: "anthropic" },
  { id: "claude-sonnet-4-6", owned_by: "anthropic" },
  { id: "claude-sonnet-4-5", owned_by: "anthropic" },
  { id: "claude-haiku-4-5", owned_by: "anthropic" },
];

const DEFAULT_PROXY_API_KEY = "x123456";

function authenticate(req: Request, res: Response, next: NextFunction): void {
  const expected = process.env["PROXY_API_KEY"] || DEFAULT_PROXY_API_KEY;
  const auth = req.headers["authorization"];
  if (!auth || !auth.startsWith("Bearer ")) {
    res.status(401).json({
      error: { message: "Missing or invalid Authorization header", type: "invalid_request_error" },
    });
    return;
  }
  const token = auth.slice("Bearer ".length).trim();
  if (token !== expected) {
    res.status(401).json({
      error: { message: "Invalid API key", type: "invalid_request_error" },
    });
    return;
  }
  next();
}

router.get("/models", authenticate, (_req, res) => {
  res.json({
    object: "list",
    data: MODELS.map((m) => ({
      id: m.id,
      object: "model",
      created: 1700000000,
      owned_by: m.owned_by,
    })),
  });
});

function isAnthropicModel(model: string): boolean {
  return model.toLowerCase().startsWith("claude");
}

interface OpenAIToolCall {
  id: string;
  type: "function";
  function: { name: string; arguments: string };
}

interface OpenAIMessage {
  role: "system" | "user" | "assistant" | "tool";
  content?: string | Array<{ type: string; text?: string; image_url?: { url: string } }> | null;
  name?: string;
  tool_calls?: OpenAIToolCall[];
  tool_call_id?: string;
}

interface ChatRequestBody {
  model: string;
  messages: OpenAIMessage[];
  stream?: boolean;
  temperature?: number;
  top_p?: number;
  max_tokens?: number;
  max_completion_tokens?: number;
  stop?: string | string[];
  tools?: Array<{
    type: "function";
    function: {
      name: string;
      description?: string;
      parameters?: Record<string, unknown>;
    };
  }>;
  tool_choice?: unknown;
  user?: string;
  response_format?: unknown;
  seed?: number;
  n?: number;
  presence_penalty?: number;
  frequency_penalty?: number;
}

function setSseHeaders(res: Response): void {
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders?.();
}

function writeSse(res: Response, data: unknown): void {
  res.write(`data: ${JSON.stringify(data)}\n\n`);
}

router.post("/chat/completions", authenticate, async (req: Request, res: Response) => {
  const body = req.body as ChatRequestBody;
  if (!body || typeof body !== "object" || !body.model || !Array.isArray(body.messages)) {
    res.status(400).json({
      error: { message: "Invalid request: model and messages are required", type: "invalid_request_error" },
    });
    return;
  }

  try {
    if (isAnthropicModel(body.model)) {
      await handleAnthropic(req, res, body);
    } else {
      await handleOpenAI(req, res, body);
    }
  } catch (err) {
    const e = err as { status?: number; message?: string; error?: unknown };
    req.log?.error({ err }, "proxy upstream error");
    const status = typeof e.status === "number" ? e.status : 500;
    const payload = {
      error: {
        message: e.message ?? "Upstream error",
        type: "upstream_error",
        details: e.error ?? null,
      },
    };
    if (res.headersSent) {
      if (!res.writableEnded) {
        try {
          writeSse(res, payload);
          res.write("data: [DONE]\n\n");
          res.end();
        } catch {
          // ignore
        }
      }
    } else {
      res.status(status).json(payload);
    }
  }
});

async function handleOpenAI(req: Request, res: Response, body: ChatRequestBody): Promise<void> {
  const params: Record<string, unknown> = { ...body };
  delete params["stream"];

  if (body.stream) {
    setSseHeaders(res);
    const keepalive = setInterval(() => {
      try {
        res.write(": keepalive\n\n");
      } catch {
        // ignore
      }
    }, 15000);
    req.on("close", () => clearInterval(keepalive));

    const stream = await openai.chat.completions.create({
      ...(params as object),
      stream: true,
    } as unknown as Parameters<typeof openai.chat.completions.create>[0]);

    try {
      for await (const chunk of stream as AsyncIterable<unknown>) {
        writeSse(res, chunk);
      }
      res.write("data: [DONE]\n\n");
    } finally {
      clearInterval(keepalive);
      res.end();
    }
  } else {
    const completion = await openai.chat.completions.create({
      ...(params as object),
      stream: false,
    } as unknown as Parameters<typeof openai.chat.completions.create>[0]);
    res.json(completion);
  }
}

interface AnthropicConverted {
  system?: string;
  messages: Array<{
    role: "user" | "assistant";
    content: unknown;
  }>;
}

function convertMessagesToAnthropic(messages: OpenAIMessage[]): AnthropicConverted {
  const systemParts: string[] = [];
  const out: AnthropicConverted["messages"] = [];

  for (const m of messages) {
    if (m.role === "system") {
      if (typeof m.content === "string") {
        systemParts.push(m.content);
      } else if (Array.isArray(m.content)) {
        for (const part of m.content) {
          if (part.type === "text" && part.text) systemParts.push(part.text);
        }
      }
      continue;
    }

    if (m.role === "tool") {
      out.push({
        role: "user",
        content: [
          {
            type: "tool_result",
            tool_use_id: m.tool_call_id ?? "",
            content: typeof m.content === "string" ? m.content : JSON.stringify(m.content ?? ""),
          },
        ],
      });
      continue;
    }

    if (m.role === "assistant") {
      const blocks: unknown[] = [];
      if (typeof m.content === "string" && m.content.length > 0) {
        blocks.push({ type: "text", text: m.content });
      } else if (Array.isArray(m.content)) {
        for (const part of m.content) {
          if (part.type === "text" && part.text) {
            blocks.push({ type: "text", text: part.text });
          }
        }
      }
      if (m.tool_calls) {
        for (const tc of m.tool_calls) {
          let parsedArgs: unknown = {};
          try {
            parsedArgs = tc.function.arguments ? JSON.parse(tc.function.arguments) : {};
          } catch {
            parsedArgs = { _raw: tc.function.arguments };
          }
          blocks.push({
            type: "tool_use",
            id: tc.id,
            name: tc.function.name,
            input: parsedArgs,
          });
        }
      }
      out.push({ role: "assistant", content: blocks.length ? blocks : "" });
      continue;
    }

    // user
    if (typeof m.content === "string") {
      out.push({ role: "user", content: m.content });
    } else if (Array.isArray(m.content)) {
      const blocks: unknown[] = [];
      for (const part of m.content) {
        if (part.type === "text" && part.text) {
          blocks.push({ type: "text", text: part.text });
        } else if (part.type === "image_url" && part.image_url?.url) {
          const url = part.image_url.url;
          if (url.startsWith("data:")) {
            const match = url.match(/^data:(.+?);base64,(.*)$/);
            if (match) {
              blocks.push({
                type: "image",
                source: { type: "base64", media_type: match[1], data: match[2] },
              });
            }
          } else {
            blocks.push({ type: "image", source: { type: "url", url } });
          }
        }
      }
      out.push({ role: "user", content: blocks });
    } else {
      out.push({ role: "user", content: "" });
    }
  }

  return {
    ...(systemParts.length ? { system: systemParts.join("\n\n") } : {}),
    messages: out,
  };
}

function convertToolsToAnthropic(tools?: ChatRequestBody["tools"]): unknown[] | undefined {
  if (!tools || tools.length === 0) return undefined;
  return tools.map((t) => ({
    name: t.function.name,
    description: t.function.description ?? "",
    input_schema: t.function.parameters ?? { type: "object", properties: {} },
  }));
}

function convertToolChoiceToAnthropic(tc: unknown): unknown {
  if (!tc) return undefined;
  if (tc === "auto") return { type: "auto" };
  if (tc === "none") return undefined;
  if (tc === "required") return { type: "any" };
  if (typeof tc === "object" && tc !== null) {
    const obj = tc as { type?: string; function?: { name?: string } };
    if (obj.type === "function" && obj.function?.name) {
      return { type: "tool", name: obj.function.name };
    }
  }
  return undefined;
}

async function handleAnthropic(req: Request, res: Response, body: ChatRequestBody): Promise<void> {
  const { system, messages } = convertMessagesToAnthropic(body.messages);
  const tools = convertToolsToAnthropic(body.tools);
  const toolChoice = convertToolChoiceToAnthropic(body.tool_choice);
  const maxTokens = body.max_tokens ?? body.max_completion_tokens ?? 8192;

  const params: Record<string, unknown> = {
    model: body.model,
    max_tokens: maxTokens,
    messages,
  };
  if (system) params["system"] = system;
  if (tools) params["tools"] = tools;
  if (toolChoice) params["tool_choice"] = toolChoice;
  // Anthropic: top_p is deprecated on newer Claude models, and several models reject
  // requests that set both temperature and top_p. Forward only temperature.
  if (typeof body.temperature === "number") {
    params["temperature"] = body.temperature;
  }
  if (body.stop) params["stop_sequences"] = Array.isArray(body.stop) ? body.stop : [body.stop];

  const created = Math.floor(Date.now() / 1000);
  const completionId = `chatcmpl-${Math.random().toString(36).slice(2, 12)}`;

  if (body.stream) {
    setSseHeaders(res);
    const keepalive = setInterval(() => {
      try {
        res.write(": keepalive\n\n");
      } catch {
        // ignore
      }
    }, 15000);
    req.on("close", () => clearInterval(keepalive));

    const stream = anthropic.messages.stream(
      params as unknown as Parameters<typeof anthropic.messages.stream>[0],
    );

    let role: "assistant" = "assistant";
    let firstChunkSent = false;
    const toolCallIndex = new Map<number, { id: string; name: string; argsBuffer: string }>();
    let finishReason: string | null = null;

    try {
      for await (const event of stream as AsyncIterable<{ type: string; [k: string]: unknown }>) {
        const t = event.type;
        if (t === "message_start") {
          const m = (event as { message?: { role?: "assistant" } }).message;
          if (m?.role) role = m.role;
        } else if (t === "content_block_start") {
          const cb = event as unknown as { index: number; content_block: { type: string; id?: string; name?: string } };
          if (cb.content_block.type === "tool_use") {
            toolCallIndex.set(cb.index, {
              id: cb.content_block.id ?? `call_${Math.random().toString(36).slice(2, 10)}`,
              name: cb.content_block.name ?? "",
              argsBuffer: "",
            });
            const delta: Record<string, unknown> = {
              tool_calls: [
                {
                  index: cb.index,
                  id: toolCallIndex.get(cb.index)!.id,
                  type: "function",
                  function: { name: toolCallIndex.get(cb.index)!.name, arguments: "" },
                },
              ],
            };
            if (!firstChunkSent) {
              delta["role"] = role;
              firstChunkSent = true;
            }
            writeSse(res, {
              id: completionId,
              object: "chat.completion.chunk",
              created,
              model: body.model,
              choices: [{ index: 0, delta, finish_reason: null }],
            });
          }
        } else if (t === "content_block_delta") {
          const cd = event as unknown as {
            index: number;
            delta: { type: string; text?: string; partial_json?: string };
          };
          if (cd.delta.type === "text_delta" && cd.delta.text) {
            const delta: Record<string, unknown> = { content: cd.delta.text };
            if (!firstChunkSent) {
              delta["role"] = role;
              firstChunkSent = true;
            }
            writeSse(res, {
              id: completionId,
              object: "chat.completion.chunk",
              created,
              model: body.model,
              choices: [{ index: 0, delta, finish_reason: null }],
            });
          } else if (cd.delta.type === "input_json_delta" && cd.delta.partial_json !== undefined) {
            const tc = toolCallIndex.get(cd.index);
            if (tc) tc.argsBuffer += cd.delta.partial_json;
            writeSse(res, {
              id: completionId,
              object: "chat.completion.chunk",
              created,
              model: body.model,
              choices: [
                {
                  index: 0,
                  delta: {
                    tool_calls: [
                      {
                        index: cd.index,
                        function: { arguments: cd.delta.partial_json },
                      },
                    ],
                  },
                  finish_reason: null,
                },
              ],
            });
          }
        } else if (t === "message_delta") {
          const md = event as { delta?: { stop_reason?: string } };
          const sr = md.delta?.stop_reason;
          if (sr) finishReason = mapStopReason(sr);
        }
      }

      writeSse(res, {
        id: completionId,
        object: "chat.completion.chunk",
        created,
        model: body.model,
        choices: [{ index: 0, delta: {}, finish_reason: finishReason ?? "stop" }],
      });
      res.write("data: [DONE]\n\n");
    } finally {
      clearInterval(keepalive);
      res.end();
    }
    return;
  }

  const message = await anthropic.messages.create(
    params as unknown as Parameters<typeof anthropic.messages.create>[0],
  ) as {
    id: string;
    role: "assistant";
    content: Array<{ type: string; text?: string; id?: string; name?: string; input?: unknown }>;
    stop_reason: string;
    usage?: { input_tokens?: number; output_tokens?: number };
  };

  let textContent = "";
  const toolCalls: OpenAIToolCall[] = [];
  for (const block of message.content) {
    if (block.type === "text" && block.text) textContent += block.text;
    else if (block.type === "tool_use") {
      toolCalls.push({
        id: block.id ?? `call_${Math.random().toString(36).slice(2, 10)}`,
        type: "function",
        function: {
          name: block.name ?? "",
          arguments: JSON.stringify(block.input ?? {}),
        },
      });
    }
  }

  const finishReason = mapStopReason(message.stop_reason);

  res.json({
    id: completionId,
    object: "chat.completion",
    created,
    model: body.model,
    choices: [
      {
        index: 0,
        message: {
          role: "assistant",
          content: textContent || null,
          ...(toolCalls.length ? { tool_calls: toolCalls } : {}),
        },
        finish_reason: finishReason,
      },
    ],
    usage: {
      prompt_tokens: message.usage?.input_tokens ?? 0,
      completion_tokens: message.usage?.output_tokens ?? 0,
      total_tokens: (message.usage?.input_tokens ?? 0) + (message.usage?.output_tokens ?? 0),
    },
  });
}

function mapStopReason(reason: string): string {
  switch (reason) {
    case "end_turn":
    case "stop_sequence":
      return "stop";
    case "max_tokens":
      return "length";
    case "tool_use":
      return "tool_calls";
    default:
      return "stop";
  }
}

export default router;
