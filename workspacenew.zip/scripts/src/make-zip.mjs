#!/usr/bin/env node
// Minimal pure-Node ZIP writer (deflate). No external deps.
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import crypto from "node:crypto";

const ROOT = process.argv[2] ?? process.cwd();
const OUT = process.argv[3] ?? "out.zip";
const PREFIX = process.argv[4] ?? "";

const EXCLUDE_DIRS = new Set([
  "node_modules",
  ".git",
  ".cache",
  ".local",
  ".agents",
  "downloads",
  "dist",
  "attached_assets",
  ".upm",
]);

function shouldSkipFile(name, abs) {
  if (name.endsWith(".log")) return true;
  if (name === ".DS_Store") return true;
  return false;
}

function walk(dir, rel, out) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, e.name);
    const r = rel ? `${rel}/${e.name}` : e.name;
    if (e.isDirectory()) {
      if (EXCLUDE_DIRS.has(e.name)) continue;
      walk(abs, r, out);
    } else if (e.isFile()) {
      if (shouldSkipFile(e.name, abs)) continue;
      out.push({ abs, rel: r });
    }
  }
}

function dosTime(d = new Date()) {
  const time =
    ((d.getHours() & 0x1f) << 11) |
    ((d.getMinutes() & 0x3f) << 5) |
    ((Math.floor(d.getSeconds() / 2)) & 0x1f);
  const date =
    (((d.getFullYear() - 1980) & 0x7f) << 9) |
    (((d.getMonth() + 1) & 0xf) << 5) |
    (d.getDate() & 0x1f);
  return { time, date };
}

const files = [];
walk(ROOT, "", files);
files.sort((a, b) => a.rel.localeCompare(b.rel));

const fd = fs.openSync(OUT, "w");
let offset = 0;
const central = [];
const { time, date } = dosTime();

for (const f of files) {
  const data = fs.readFileSync(f.abs);
  const compressed = zlib.deflateRawSync(data, { level: 9 });
  const useDeflate = compressed.length < data.length;
  const payload = useDeflate ? compressed : data;
  const method = useDeflate ? 8 : 0;
  const crc = crypto.createHash("crc32" in crypto.getHashes() ? "crc32" : "md5"); // fallback unused
  // Compute CRC-32 ourselves (simple table)
  const crc32 = makeCrc32(data);
  const nameBuf = Buffer.from(`${PREFIX}${f.rel}`, "utf8");

  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50, 0);
  local.writeUInt16LE(20, 4); // version needed
  local.writeUInt16LE(0x0800, 6); // bit 11: utf-8 names
  local.writeUInt16LE(method, 8);
  local.writeUInt16LE(time, 10);
  local.writeUInt16LE(date, 12);
  local.writeUInt32LE(crc32, 14);
  local.writeUInt32LE(payload.length, 18);
  local.writeUInt32LE(data.length, 22);
  local.writeUInt16LE(nameBuf.length, 26);
  local.writeUInt16LE(0, 28);

  fs.writeSync(fd, local);
  fs.writeSync(fd, nameBuf);
  fs.writeSync(fd, payload);

  central.push({
    nameBuf,
    method,
    time,
    date,
    crc32,
    csize: payload.length,
    size: data.length,
    offset,
  });

  offset += local.length + nameBuf.length + payload.length;
}

const cdStart = offset;
let cdSize = 0;
for (const c of central) {
  const h = Buffer.alloc(46);
  h.writeUInt32LE(0x02014b50, 0);
  h.writeUInt16LE(20, 4); // version made by
  h.writeUInt16LE(20, 6); // version needed
  h.writeUInt16LE(0x0800, 8);
  h.writeUInt16LE(c.method, 10);
  h.writeUInt16LE(c.time, 12);
  h.writeUInt16LE(c.date, 14);
  h.writeUInt32LE(c.crc32, 16);
  h.writeUInt32LE(c.csize, 20);
  h.writeUInt32LE(c.size, 24);
  h.writeUInt16LE(c.nameBuf.length, 28);
  h.writeUInt16LE(0, 30);
  h.writeUInt16LE(0, 32);
  h.writeUInt16LE(0, 34);
  h.writeUInt16LE(0, 36);
  h.writeUInt32LE(0, 38);
  h.writeUInt32LE(c.offset, 42);
  fs.writeSync(fd, h);
  fs.writeSync(fd, c.nameBuf);
  cdSize += h.length + c.nameBuf.length;
}

const eocd = Buffer.alloc(22);
eocd.writeUInt32LE(0x06054b50, 0);
eocd.writeUInt16LE(0, 4);
eocd.writeUInt16LE(0, 6);
eocd.writeUInt16LE(central.length, 8);
eocd.writeUInt16LE(central.length, 10);
eocd.writeUInt32LE(cdSize, 12);
eocd.writeUInt32LE(cdStart, 16);
eocd.writeUInt16LE(0, 20);
fs.writeSync(fd, eocd);
fs.closeSync(fd);

const stat = fs.statSync(OUT);
console.log(
  JSON.stringify(
    { out: OUT, files: files.length, sizeBytes: stat.size, sizeMB: (stat.size / 1048576).toFixed(2) },
    null,
    2,
  ),
);

// CRC-32
function makeCrc32(buf) {
  let table = makeCrc32.table;
  if (!table) {
    table = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      table[n] = c >>> 0;
    }
    makeCrc32.table = table;
  }
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = table[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
