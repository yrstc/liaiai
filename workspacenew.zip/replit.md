# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

This project hosts an **OpenAI-compatible AI gateway**: a thin reverse-proxy API that exposes one endpoint for both OpenAI and Anthropic models, plus a small front-end portal that displays the credentials and a quick-start guide.

## Artifacts

- `artifacts/api-server` (`@workspace/api-server`) — Express 5 server.
  - `/api/healthz` — health check
  - `/v1/models` — OpenAI-style model list (Bearer auth)
  - `/v1/chat/completions` — OpenAI-style chat completions (Bearer auth)
    - Routes by model prefix: `gpt*`/`o*` → OpenAI, `claude*` → Anthropic
    - Supports `stream: true` (SSE) with 15s keepalive
    - Supports tool calling (auto-converts OpenAI tool schema ↔ Anthropic tool schema)
    - Body limit: 50 MB
- `artifacts/api-portal` (`@workspace/api-portal`) — React + Vite front-end.
  - Mounted at `/`. Shows Base URL, an API-key field with verify button, cURL/Python snippets, and a model list once verified. Stores the entered key only in `localStorage`.
- `artifacts/mockup-sandbox` — Canvas/preview sandbox (default scaffold).

## AI Provider Setup

Both providers are configured through Replit AI Integrations. No personal API keys are needed; usage is billed to the user's Replit credits. Setup was performed once via `setupReplitAIIntegrations`, which provisions:

- `AI_INTEGRATIONS_OPENAI_BASE_URL` / `AI_INTEGRATIONS_OPENAI_API_KEY`
- `AI_INTEGRATIONS_ANTHROPIC_BASE_URL` / `AI_INTEGRATIONS_ANTHROPIC_API_KEY`

## Secrets

- `PROXY_API_KEY` — Bearer token clients must send to call `/v1/*`. Optional; defaults to `x123456` if unset (for demo / handoff). Override in Secrets for production.
- `SESSION_SECRET` — present (general-purpose).

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **AI SDKs**: `openai`, `@anthropic-ai/sdk`
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
