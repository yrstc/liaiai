# OpenAI-Compatible AI Gateway

一个部署在 Replit 上的 **OpenAI 协议兼容**的 AI 网关。前端门户用于查看接入信息，后端服务把请求统一代理到 OpenAI / Anthropic（通过 Replit AI Integrations，无需自备 Key，按 Replit Credits 计费）。

> 接口完全兼容 OpenAI 的 `/v1/chat/completions` 与 `/v1/models`，可直接被任何 OpenAI SDK / 客户端使用，模型名以 `gpt*` / `o*` 走 OpenAI，以 `claude*` 走 Anthropic。

---

## 一、把工程交给朋友 / 在新 Replit 上从 zip 导入后的部署步骤

> 请**严格按顺序**执行，跳步会出现"环境没装好"或"密钥缺失"等问题。

### 1. 准备 Replit 环境（必须）

本工程在 Replit 上运行，所需运行时与系统依赖**已经在仓库里声明好**，导入 zip 后会自动安装，你**不需要手动安装** Node.js / pnpm 等。具体声明在：

- `.replit` —— `modules = ["nodejs-24"]`，自动提供 **Node.js 24**
- `replit.nix` —— 提供 `unzip` 等系统工具
- `.npmrc` —— 强制使用 **pnpm**（Node 24 自带 corepack，可直接使用 `pnpm`）

> 如果你是在**本地**而不是 Replit 上跑，需要自行准备：
> - Node.js **24.x**
> - pnpm **10.x**（推荐 `corepack enable && corepack prepare pnpm@10 --activate`）

### 2. 安装依赖

在 Replit Shell 里执行一次（导入 zip 后必须做）：

```bash
pnpm install
```

### 3. 配置 AI 提供方（必须）

本工程通过 **Replit AI Integrations** 调用 OpenAI 与 Anthropic，**不需要你自己的 OpenAI / Anthropic API Key**，费用走该 Replit 账号的 Credits。

让 Replit Agent 在聊天里执行一次以下指令即可（也可以让 Agent 直接帮你做）：

```text
请帮我设置 OpenAI 与 Anthropic 的 Replit AI Integrations。
```

成功后会在 Secrets 里自动生成下面 4 个变量（**不要手动改**）：

- `AI_INTEGRATIONS_OPENAI_BASE_URL`
- `AI_INTEGRATIONS_OPENAI_API_KEY`
- `AI_INTEGRATIONS_ANTHROPIC_BASE_URL`
- `AI_INTEGRATIONS_ANTHROPIC_API_KEY`

### 4. 配置网关访问 Token（可选）

`PROXY_API_KEY` 是**客户端**调用 `/v1/*` 时需要在 `Authorization: Bearer <token>` 头里带上的令牌。

- **未设置**：服务端会使用默认值 **`x123456`**，前端门户也会自动填好这个默认值，开箱即用，方便本地或交付演示。
- **生产部署**：建议在 Replit 的 **Secrets** 面板里把 `PROXY_API_KEY` 设为一段足够长的随机字符串覆盖默认值。

### 5. 启动 / 重启服务

导入 zip 后，Replit 工作流会自动起来；如果没起或者改了代码 / 密钥，可以让 Agent 帮你重启，或者在 Workflows 面板里点重启：

- `artifacts/api-server: API Server`（API 网关，端口由 Replit 注入）
- `artifacts/api-portal: web`（前端门户）
- `artifacts/mockup-sandbox: Component Preview Server`（画布预览，可选）

### 6. 验证是否成功

在 Shell 里执行：

```bash
curl -s "https://$REPLIT_DEV_DOMAIN/api/healthz"
# {"status":"ok"}

curl -s -H "Authorization: Bearer x123456" \
  "https://$REPLIT_DEV_DOMAIN/v1/models" | head -c 200
# {"object":"list","data":[{"id":"gpt-5.4",...}, ...]}
```

> 把 `x123456` 换成你自己设置的 `PROXY_API_KEY`（如果有覆盖）。

### 7. 发布到生产环境（可选）

在 Replit 顶部点击 **Publish / Deploy** 即可，本仓库已配置好 `autoscale` 部署目标。

---

## 二、调用示例

> Base URL 就是前端门户上显示的那个，形如 `https://<你的域名>/v1`。

### cURL

```bash
curl https://<你的域名>/v1/chat/completions \
  -H "Authorization: Bearer x123456" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-5.4",
    "messages": [{"role":"user","content":"你好"}]
  }'
```

### Python（OpenAI SDK）

```python
from openai import OpenAI

client = OpenAI(
    base_url="https://<你的域名>/v1",
    api_key="x123456",
)

resp = client.chat.completions.create(
    model="gpt-5.4",                # 或者 "claude-sonnet-4-5"
    messages=[{"role": "user", "content": "你好"}],
)
print(resp.choices[0].message.content)
```

模型名以 `gpt` / `o` 开头会走 OpenAI，以 `claude` 开头会走 Anthropic，**调用方完全不用关心后端是谁**。

---

## 三、工程结构

```
.
├── artifacts/
│   ├── api-server/      # Express 5 网关服务（/api/healthz, /v1/models, /v1/chat/completions）
│   ├── api-portal/      # React + Vite 前端门户
│   └── mockup-sandbox/  # 画布预览（可选）
├── lib/                 # 共享库（API 规范、Zod、DB 等）
├── scripts/             # 构建 / 合并脚本
├── .replit              # Replit 模块声明（Node.js 24 等）
├── replit.nix           # Replit 系统依赖（unzip 等）
├── pnpm-workspace.yaml  # pnpm 工作区
└── README.md            # 本文件
```

## 四、常用命令

```bash
pnpm install                                  # 安装依赖（首次必做）
pnpm run typecheck                            # 全工程类型检查
pnpm run build                                # 类型检查 + 全工程构建
pnpm --filter @workspace/api-server run dev   # 单独跑后端
pnpm --filter @workspace/api-spec run codegen # 重新生成 API hooks / Zod
```

## 五、安全提示

- 默认的 `PROXY_API_KEY = x123456` **仅适合演示和内部交付**。对外发布前，请务必在 Secrets 里设置一个强随机的 `PROXY_API_KEY`。
- AI Integrations 的 4 个 `AI_INTEGRATIONS_*` 变量由 Replit 注入，**请勿手动修改或写入代码仓库**。
